//
//  ViewController.swift
//  photoGallary
//
//  Created by Mac on 7/31/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import Photos

class CollectionViewCell: UICollectionViewCell
    
{
    @IBOutlet weak var imgView: UIImageView!
    
}

class ViewController: UIViewController , UISearchControllerDelegate, UICollectionViewDataSource{
    
    @IBOutlet weak var collView: UICollectionView!
    
    var imageArray = [UIImage]()

    override func viewDidLoad() {
        super.viewDidLoad()
 
        grabPhoto()
    }

   
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
       return imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell:CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier:"CollectionViewCell" , for: indexPath)as! CollectionViewCell
        
        let imgeView = cell.viewWithTag(1) as! UIImageView
        
        
        imgeView.image = imageArray[indexPath.row]
        return cell
    }
    
   
    
    
    func grabPhoto()
    {
       
        
        let imgManager = PHImageManager.default()
        let requestOption = PHImageRequestOptions()
        requestOption.isSynchronous = true
        requestOption.deliveryMode = .highQualityFormat
        
        let fetchOption =  PHFetchOptions()
        fetchOption.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
        
        if  let fetchResult : PHFetchResult = PHAsset.fetchAssets(with: .image, options: fetchOption){
            
            if fetchResult.count > 0
            {
                for i in 0..<fetchResult.count{
                    imgManager.requestImage(for: fetchResult.object(at: i), targetSize: CGSize(width:100 , height:100), contentMode: .aspectFit , options: requestOption, resultHandler: { images , error  in
                        
                        self.imageArray.append(images!)
                        self.collView.reloadData()
                    })
                }
                
            }else{
                
                print("No photo loaded")
                
                
                
            }
        }
    }

}

