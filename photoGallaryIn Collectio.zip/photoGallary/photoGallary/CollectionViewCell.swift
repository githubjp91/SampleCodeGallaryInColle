//
//  CollectionViewCell.swift
//  photoGallary
//
//  Created by Mac on 7/31/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}
